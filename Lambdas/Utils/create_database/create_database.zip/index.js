const pg = require('pg');

exports.handler = async (event) => {

    const { SQLcommand } = event;
    // Use the pg Client
    const Client = pg.Client;
    // note: you will need to create the database!
    const client = new Client({
        connectionString: process.env.DATABASE_URL,
        ssl: process.env.PGSSLMODE && { rejectUnauthorized: false }
    });

    const response = client.query(SQLcommand)
    return response;
};
