
module.exports = ({ snippet }) => {
    const { publishedAt, title, description, thumbnails, resourceId } = snippet;
    return {
        published_at: publishedAt,
        title,
        description,
        thumbnail_url: thumbnails.url,
        video_id: resourceId.videoId
    }
}
