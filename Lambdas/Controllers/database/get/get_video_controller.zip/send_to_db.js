const pg = require('pg');

module.exports = (command) => {

    // Use the pg Client
    const Client = pg.Client;
    // note: you will need to create the database!
    const client = new Client({
        connectionString: process.env.DATABASE_URL,
        ssl: process.env.PGSSLMODE && { rejectUnauthorized: false }
    });

    const response = client.query(`CREATE TABLE test (
        id SERIAL PRIMARY NOT NULL,
        data BOOLEAN NOT NULL
        );
        `)

    console.log(response);
}