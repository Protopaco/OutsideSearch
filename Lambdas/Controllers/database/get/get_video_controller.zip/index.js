
const seed_db = require("./seed_db")

exports.handler = async (event) => {
    const { queryStringParameters } = event;

    if (queryStringParameters && queryStringParameters.id) {
        console.log(queryStringParameters.id)
    }

    await seed_db();


    return { statusCode: 200 }

};
