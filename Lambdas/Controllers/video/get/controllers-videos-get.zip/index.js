const db_client = require("./db_client");

exports.handler = async (event) => {
    const { queryStringParameters } = event;

    if (event.queryStringParameters && event.queryStringParameters.id) {
        const SQLCommand = `SELECT * FROM videos WHERE id = ${queryStringParameters.id}`;
        const { rows } = await db_client(SQLCommand);
        return {
            statusCode: 200,
            body: JSON.stringify(rows)
        }
    }

    const offset = queryStringParameters.offset || 0;
    const SQLCommand = `SELECT * FROM videos ORDER BY created_at LIMIT 25 OFFSET ${offset}`;
    const { rows } = await db_client(SQLCommand);

    return {
        statusCode: 200,
        body: JSON.stringify(rows),
    };
};
