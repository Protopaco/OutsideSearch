const db_client = require('./db_client')

exports.handler = async ({ body }) => {
    const { name, img_url, info_url } = body;

    if (name && img_url && info_url) {
        const SQLCommand = `INSERT INTO games (name, img_url, info_url) VALUES (${name}, ${img_url}, ${info_url}) RETURNING *`
        try {
            const { rows } = await db_client(SQLCommand)

            return {
                statusCode: 200,
                body: JSON.stringify(rows),
            };
        } catch (e) {
            console.log(e.message)
            return { statusCode: 500, body: e }
        }

    }

    return {
        statusCode: 500,
        body: JSON.stringify({ "error": "Invalid data" })
    }
};
